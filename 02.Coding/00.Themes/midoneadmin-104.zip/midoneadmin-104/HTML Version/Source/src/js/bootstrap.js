// Load plugins
import $ from 'jquery'
import helper from './helper'

// Set plugins globally
window.$ = window.jQuery = $
window.helper = helper